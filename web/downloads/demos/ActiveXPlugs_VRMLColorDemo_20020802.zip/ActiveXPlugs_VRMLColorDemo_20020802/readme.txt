Color information transmision/receival demo (from an HTML window to 
another HTML window where the received color is shown on a VRML 
client ActiveX control as the color of a 3D object - a sphere)

* ColorProvider.html:

Colors here are ranging from 0 to 127. Values of 128 
and more cause an overflow (cause of a bug in the COM
interface definition of ColorPlugX)

Thanks to Sergey Bederov from ParallelGraphics for spotting this

* ColorConsumer.html:

divides RGB elements of the incoming color by 127 (see above 
why not by 255) in order to get a floating point from 0 to 1
to pass to the VRML

Requires Cortona VRML player ActiveX control from
http://wwww.ParallelGraphics.com
