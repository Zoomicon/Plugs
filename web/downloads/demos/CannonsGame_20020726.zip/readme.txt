* Title: Cannons multi-player game
* Author: Sergey Bederov (bederov@parallelgraphics.com)
* Version: 26Jul2002

* Requirements: 
1) ActiveXPlugs (http://members.fortunecity.com/birbilis/Plugs)
2) ParallelGraphics Cortona VRML player (http://www.parallelgraphics.com)

* Instructions:
1) Open up as many instances of "cannons.html" as the players (2 or more), either on the same computer or on different ones (using the NetPlug application to link them)
2) Click on the door's name placeholder and write your name, then press ENTER
3) The door opens and you can enter the log-in room
4) Select the player you want to play with by clicking on their bouncing ball
5) You always play the left side (red) on the window (one window per player), players can play simultaneously (that is not necesserily in turns)
6) To fire, drag on the cannon to set its shooting angle and fire power

have fun,
George Birbilis (birbilis@kagi.com)

many thanks to Sergey!
If any of you have a cool demo to submit, please contact me (G.Birbilis) and if it's cool enough you'll earn yourself a registered version of the ActiveXPlugs installer!
