function message=sendVariant(providerID,message)
%SENDVARIANT Send a variant message via a VariantPlugX with a specific providerID
%  SENDVARIANT(PROVIDERID) will create a VariantPlugX (if needed) and set
%  its 'provider' and 'content' properties accordingly.
%  Returns message

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/01 17:25:00 $

% [1] Create VARIANT_PLUG global variable if needed, holding a variant plug
if ~exist('VARIANT_PLUG')
   global VARIANT_PLUG;
   VARIANT_PLUG = actxserver('ActiveXPlugs.VariantPlugX');
end

% [2] Set the plug's 'id' property
set(VARIANT_PLUG,'id',providerID);

% [3] Set the 'content' property of the plug to transmit the message
set(VARIANT_PLUG,'content',message);
