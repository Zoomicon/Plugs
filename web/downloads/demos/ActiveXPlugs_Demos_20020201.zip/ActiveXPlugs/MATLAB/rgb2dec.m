function dec=rgb2dec(r,g,b)
%RGB2DEC Convert r,g,b numbers to a decimal color value
%  RGB2DEC(r,g,b) will create a decimal number using 1-byte per color
%  and return that value

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/02 18:46:00 $

dec=hex2dec(strcat(dec2hex(b,2),dec2hex(g,2),dec2hex(r,2))); %Windows uses BGR format, not RGB
