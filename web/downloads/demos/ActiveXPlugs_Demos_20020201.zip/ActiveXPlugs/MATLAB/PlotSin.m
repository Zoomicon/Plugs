%PLOTSIN Sends a series of points to plot the sin function
%  PLOTSIN will do a loop and send some sin(x) values using SendPoint

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.1 $ $Date: 2001/12/02 19:01:00 $

colorProviderID='{44BDFB3A-DE97-4F3E-9783-C052CEEA132F}';
lineProviderID='{CDC1EE3B-4F0C-4BC4-98A3-DECB75109456}';

OffsetY=50;
ScaleX=3;
for x=0:100,
 sendColor(colorProviderID,randomColor);
 sendPoint(lineProviderID,x*ScaleX,sin(x*ScaleX)*OffsetY+OffsetY);
end 

%NOTE: "for" and "end" must be in small caps, else MATLAB will display
% the cryptic error "??? Attempt to execute SCRIPT for as a function."
