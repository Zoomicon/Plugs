function v=sendPointsVector(providerID,v)
%SENDPOINTSVECTOR Send a vector of points using SendPoint function
%  SENDPOINTSVECTOR(PROVIDERID,v) will iterate on the vector elements
%  and call SendPoint for each one of them
%  Returns the points vector

%  example: sendPointsVector('{CDC1EE3B-4F0C-4BC4-98A3-DECB75109456}',[[0;0],[10;10],[100;200]])

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/02 18:14:00 $

for i=1:length(v)-1,
 sendPoint(providerID,v(1,i),v(2,i)); %x=v(1,i), y=v(2,i)
end 

%NOTE: "for" and "end" must be in small caps, else MATLAB will display
% the cryptic error "??? Attempt to execute SCRIPT for as a function."
