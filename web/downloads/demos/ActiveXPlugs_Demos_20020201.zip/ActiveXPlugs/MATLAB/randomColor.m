function color=randomColor()
%RANDOMCOLOR Return a random RGB color decimal 
%  RANDOMCOLOR() will return a random RGB color decimal (1 byte per color element)

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/02 18:53:00 $

color=rgb2dec(randomColorElement,randomColorElement,randomColorElement);
