function color=sendColor(providerID,color)
%SENDCOLOR Send an RGB color via a ColorPlugX with a specific providerID
%  SENDCOLOR(PROVIDERID,color) will create a ColorPlugX (if needed) and set
%  its 'provider' and 'color' properties accordingly.
%  Returns the color

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.1 $ $Date: 2001/12/02 19:01:00 $

% [1] Create COLOR_PLUG global variable if needed, holding a ColorPlugX
if ~exist('COLOR_PLUG')
   global COLOR_PLUG;
   COLOR_PLUG = actxserver('ActiveXPlugs.ColorPlugX');
end

% [2] Set the plug's 'id' property
set(COLOR_PLUG,'id',providerID);

% [3] Set the 'content' property of the plug
set(COLOR_PLUG,'content',color);
