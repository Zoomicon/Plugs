function StringPlugX_newContent(varargin)
%STRINGPLUGX_EVENT Sample OnNewContent event handler for StringPlugX.
%  STRINGPLUGX_EVENT is a sample OnNewContent event handler function for StringPlugX.
%
%  See also: EVALSAMP, SAMPEV, MWSAMP and ACTXCONTROL.

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/02 20:55:00

value=get(h,'content');

result=sin(str2num(value));
SendString('{02006860-6E9E-4820-846C-E402BA6B0F65}',num2str(result));