%EVALSAMP Sample script to create StringPlugX object.
%  Script to create a StringPlugX control and have it listen for 
%  matlab commands to evaluate
%
%  StringPlug_newContent is the event handler for this control. The 
%  only event fired by the control is 'OnNewContent', which is fired 
%  when new content arrives at the StringPlugX. The event handler 
%  evaluates the string passed in and writes it out in the Matlab 
%  command window when the event is fired.
%
%  See also: StringPlugX_newContent, MWSAMP, SAMPEV and ACTXCONTROL.

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/02 21:04:00 $

% Create a figure
f = figure('Position', [0 0 30 30]);

% create the StringPlugX object
global h;
h = actxcontrol('ActiveXPlugs.StringPlugX',[0 0 20 20],f,{'OnNewContent' 'StringPlugX_newContent'});

% set the provider property
set(h,'provider','{EE02722D-2234-42AA-8FE4-9E825BCFA8AC}');

%close the figure to destroy the control
%release(h)