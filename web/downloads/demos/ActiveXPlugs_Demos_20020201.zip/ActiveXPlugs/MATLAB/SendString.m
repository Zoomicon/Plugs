function message=sendString(providerID,message)
%SENDSTRING Send a string message via a StringPlugX with a specific providerID
%  SENDSTRING(PROVIDERID, MESSAGE) will create a StringPlugX (if needed) and set
%  its 'provider' and 'content' properties accordingly.
%  Returns message

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 2.0 $ $Date: 2001/12/01 17:25:00 $

% [1] Create STRING_PLUG global variable if needed, holding a string plug
if ~exist('STRING_PLUG')
   global STRING_PLUG;
   STRING_PLUG = actxserver('ActiveXPlugs.StringPlugX');
end

% [2] Set the plug's 'id' property
set(STRING_PLUG,'id',providerID);

% [3] Set the 'content' property of the plug to transmit the message
set(STRING_PLUG,'content',message);
