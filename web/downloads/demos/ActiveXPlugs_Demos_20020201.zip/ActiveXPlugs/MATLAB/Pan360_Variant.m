%Pan360_Variant Sample script to pan 360 degrees a QTVR panorama via variant plug
%  Script to pan 360 degrees a QTVR panorama via variant plug. The script:
%  Just loops from 0 up to 360 and broadcasts the counter value%
%
%  See also: SendVariant

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/01 17:25:00 

for i=0:360,
   SendVariant('{C0BA74EE#517B#491E#9A4A#0F4108619EC1}',i);
end
