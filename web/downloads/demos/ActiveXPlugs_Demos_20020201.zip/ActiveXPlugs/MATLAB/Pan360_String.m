%Pan360_String Sample script to pan 360 degrees a QTVR panorama via string plug
%  Script to pan 360 degrees a QTVR panorama via string plug. The script:
%  Just loops from 0 up to 360 and broadcasts the counter value%
%
%  See also: SendString

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 2.0 $ $Date: 2001/12/01 17:25:00 

for i=0:360,
   SendString('{C0BA74EE-517B-491E-9A4A-0F4108619EC1}',i);
end
