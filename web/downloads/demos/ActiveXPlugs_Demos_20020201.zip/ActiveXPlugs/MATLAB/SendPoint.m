function v=sendPoint(providerID,x,y)
%SENDPOINT Send a point via a PointPlugX with a specific providerID
%  SENDPOINT(PROVIDERID,x,y) will create a PointPlugX (if needed) and set
%  its 'provider' and 'contentX','contentY' properties accordingly.
%  Returns [x;y] vector

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/02 17:35:00 $

% [1] Create POINT_PLUG global variable if needed, holding a PointPlugX
if ~exist('POINT_PLUG')
   global POINT_PLUG;
   POINT_PLUG = actxserver('ActiveXPlugs.PointPlugX');
end

% [2] Set the plug's 'id' property
set(POINT_PLUG,'id',providerID);

% [3] Temporarily disable the 'outputEnabled' property of the plug
set(POINT_PLUG,'outputEnabled',0); %FALSE=0

% [4] Set the 'contentX' property of the plug 
set(POINT_PLUG,'contentX',x);

% [5] Enable again the 'outputEnabled' property of the plug
set(POINT_PLUG,'outputEnabled',1); %TRUE=1

% [6] Set the 'contentY' property of the plug, resulting in point (x,y) being sent
set(POINT_PLUG,'contentY',y);

% [7] Create return vector
v=[x;y];
