%StringInOut Sample script to exchange data via plugs
%  Script to exchange data via plugs. The script:
%  1) Creates a StringInputPinX object and sets a GUID
%     to its 'provider' property 
%  2) Creates a StringOutputPinX object and sets its 
%     'id' property to the same GUID value
%  3) Prompts the user to enter a string and sets it to the
%     'str' property of the output plug
%  4) Gets the 'str' property of the input plug and prints it
%  5) Deletes the two objects
%  6) Deallocate all local variables that have been allocated
%
%  See also: ...

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/11/26 12:25:00 $

identity='{D77D8C53-DC7A-4e17-A979-BA88F92E8EC5}';

% [1] Create input plug and set its 'provider' property
in=actxserver('ActiveXPlugs.StringPlugX');
set(in,'provider',identity);

% [2] Create output plug and set its 'id' property
out=actxserver('ActiveXPlugs.StringPlugX');
set(out,'id',identity);

% [3] Prompt the user to enter a string
reply=input('Give me a string: ','s');
% set the 'str' property of the output plug to the user reply
set(out,'content',reply);

% [4] Get the 'str' property of the input plug
message=get(in,'content');
% display the received text
message

% [5] Delete the two objects
delete(in);
delete(out);

% [6] Deallocate variables
clear in out identity reply message;
% "ans" is a variable allocated by MATLAB, since "set" is a function and we used it as a proc
clear ans;
