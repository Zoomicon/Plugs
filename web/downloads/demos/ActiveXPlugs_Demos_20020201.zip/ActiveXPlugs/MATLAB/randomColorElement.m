function e=randomColorElement
%RANDOMCOLORELEMENT Return a random RGB color element (from 0 to 255)
%  RANDOMCOLOR() will return a random RGB color element (1 byte)

% Copyright (c) 2001 by George Birbilis <birbilis@kagi.com>
% $Revision: 1.0 $ $Date: 2001/12/02 18:53:00 $

e=round(rand*255);
